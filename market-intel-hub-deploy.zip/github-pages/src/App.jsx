import React, { useState, useCallback } from 'react';
import { Search, Bell, Settings, Database, Users, BarChart3, Target, Building, FileText, Calendar, TrendingUp, Clock, ExternalLink, Filter, Plus, RefreshCw, ChevronRight, Briefcase, DollarSign, Award, Zap, Layers, X, Cloud, GitBranch, ArrowUpRight, Menu, Home, BookOpen, CheckCircle } from 'lucide-react';

// Real DHS Opportunities from G2Xchange
const OPPORTUNITIES = [
  { 
    id: 'g2x_001', 
    title: "Notice Regarding Funding Pause - Temporary Restraining Order", 
    agency: "Department of Homeland Security", 
    acronym: "DHS",
    value: null, 
    valueDisplay: "TBD", 
    stage: "Special Notice", 
    dueDate: "2026-02-03", 
    postedDate: "2026-02-02",
    source: "G2X-SAM", 
    score: 72, 
    vehicle: "N/A", 
    naics: "",
    solicitationId: "001-25",
    description: "Notice of a Court Order regarding certain Federal financial assistance programs, including grants.",
  },
  { 
    id: 'g2x_002', 
    title: "Final Order in Wilmer Hale LLP Matter", 
    agency: "Department of Homeland Security", 
    acronym: "DHS",
    value: null, 
    valueDisplay: "TBD", 
    stage: "Special Notice", 
    dueDate: "2026-02-28", 
    postedDate: "2026-01-15",
    source: "G2X-SAM", 
    score: 65, 
    vehicle: "N/A", 
    naics: "",
    solicitationId: "DHS-002-0609",
    description: "Final order documentation for administrative matter.",
  },
  { 
    id: 'g2x_003', 
    title: "Request for Information (RFI) - Cybersecurity Services", 
    agency: "Department of Homeland Security", 
    acronym: "DHS",
    value: 45000000, 
    valueDisplay: "$45M", 
    stage: "RFI", 
    dueDate: "2026-02-20", 
    postedDate: "2026-01-18",
    source: "G2X-SAM", 
    score: 91, 
    vehicle: "EAGLE II", 
    naics: "561612",
    solicitationId: "70RCSA25R00000001",
    description: "DHS seeks information on cybersecurity assessment and monitoring services for critical infrastructure protection.",
  },
  { 
    id: 'g2x_004', 
    title: "J&A Refuse and Recycling Services", 
    agency: "Department of Homeland Security", 
    acronym: "DHS",
    value: 2500000, 
    valueDisplay: "$2.5M", 
    stage: "J&A", 
    dueDate: "2026-03-15", 
    postedDate: "2026-01-10",
    source: "G2X-SAM", 
    score: 58, 
    vehicle: "GSA MAS", 
    naics: "562111",
    solicitationId: "70Z03325PR0000001",
    description: "Justification and Approval for refuse and recycling services at DHS facilities.",
  },
  { 
    id: 'g2x_005', 
    title: "State of Colorado Protective Security Services", 
    agency: "Department of Homeland Security", 
    acronym: "DHS",
    value: 8000000, 
    valueDisplay: "$8M", 
    stage: "Solicitation", 
    dueDate: "2026-02-14", 
    postedDate: "2026-01-05",
    source: "G2X-SAM", 
    score: 84, 
    vehicle: "BPA", 
    naics: "561612",
    solicitationId: "70RFPW19DW80000001",
    description: "Protective security services for Federal facilities in Colorado region.",
  },
  // Pipeline opportunities from your G2X account
  { 
    id: 'pipe_001', 
    title: "DHS/CBP Commercial Solutions Opening - Trade Solutions Pilot (TSP)", 
    agency: "U.S. Customs and Border Protection", 
    acronym: "CBP",
    value: null, 
    valueDisplay: "TBD", 
    stage: "Market Research", 
    dueDate: "2025-07-07", 
    postedDate: "2025-01-15",
    source: "G2X Pipeline", 
    score: 78, 
    vehicle: "CSO", 
    naics: "541512",
    solicitationId: "CSOP-BP-GS-25-0001",
    description: "Commercial Solutions Opening for trade facilitation technology pilots.",
  },
  { 
    id: 'pipe_002', 
    title: "DHS USCIS Forecast: Enterprise Automation and Unified Task Orchestration (eAUTO) Recompete", 
    agency: "U.S. Citizenship and Immigration Services", 
    acronym: "USCIS",
    value: 62000000, 
    valueDisplay: "$62M", 
    stage: "Capture Planning", 
    dueDate: "2026-06-30", 
    postedDate: "2025-12-01",
    source: "G2X Pipeline", 
    score: 88, 
    vehicle: "OASIS+", 
    naics: "541512",
    solicitationId: "USCIS-eAUTO-2026",
    description: "Recompete for enterprise automation platform supporting immigration case processing workflows.",
  },
];

const ALERTS = [
  { id: 1, type: "opportunity", title: "New DHS RFI", message: "Cybersecurity Services RFI matches your profile - 91% fit score", time: "2 hours ago", priority: "high", read: false },
  { id: 2, type: "pipeline", title: "Pipeline Update", message: "USCIS eAUTO moved to Capture Planning stage - $62M value", time: "1 day ago", priority: "high", read: false },
  { id: 3, type: "deadline", title: "Due Date Alert", message: "Colorado Protective Services due in 27 days", time: "2 days ago", priority: "medium", read: true },
  { id: 4, type: "competitor", title: "Competitor Win", message: "Leidos awarded $28M CISA contract", time: "3 days ago", priority: "medium", read: true },
];

const DATA_SOURCES = [
  { id: "g2x", name: "G2Xchange", status: "connected", lastSync: "Just now", records: 7, icon: Database },
  { id: "sam", name: "SAM.gov", status: "connected", lastSync: "via G2X", records: 213833, icon: Building },
  { id: "ebuy", name: "GSA eBuy", status: "connected", lastSync: "via G2X", records: 342, icon: FileText },
  { id: "pipeline", name: "G2X Pipelines", status: "connected", lastSync: "Just now", records: 3, icon: Target },
];

const CUSTOMERS = [
  { id: 1, name: "Department of Homeland Security", acronym: "DHS", opportunities: 5, relationships: 4, contracts: 2, spend: "$45M", health: "strong", priority: "Tier 1" },
  { id: 2, name: "Customs and Border Protection", acronym: "CBP", opportunities: 3, relationships: 2, contracts: 1, spend: "$12M", health: "growing", priority: "Tier 1" },
  { id: 3, name: "Immigration and Customs Enforcement", acronym: "ICE", opportunities: 2, relationships: 1, contracts: 0, spend: "$0", health: "new", priority: "Tier 2" },
  { id: 4, name: "U.S. Citizenship and Immigration Services", acronym: "USCIS", opportunities: 1, relationships: 3, contracts: 1, spend: "$62M", health: "strong", priority: "Tier 1" },
];

const PIPELINE_STATS = {
  totalValue: "$117M",
  activeOpps: 7,
  winRate: "34%",
  avgDaysToClose: 45,
  byStage: [
    { stage: "Market Research", count: 1, value: "TBD" },
    { stage: "RFI/SS", count: 1, value: "$45M" },
    { stage: "Solicitation", count: 2, value: "$10.5M" },
    { stage: "Capture Planning", count: 1, value: "$62M" },
    { stage: "Special Notice", count: 2, value: "TBD" },
  ]
};

// Components
const Badge = ({ children, variant = "default", size = "sm" }) => {
  const variants = {
    default: "bg-slate-700 text-slate-300",
    success: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30",
    warning: "bg-amber-500/20 text-amber-400 border border-amber-500/30",
    info: "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30",
    purple: "bg-purple-500/20 text-purple-400 border border-purple-500/30",
  };
  const sizes = { xs: "text-[10px] px-1.5 py-0.5", sm: "text-xs px-2 py-0.5" };
  return <span className={`inline-flex items-center rounded-full font-medium ${variants[variant]} ${sizes[size]}`}>{children}</span>;
};

const StatCard = ({ icon: Icon, label, value, trend, trendUp, subtitle }) => (
  <div className="group bg-gradient-to-br from-slate-800/80 to-slate-800/40 border border-slate-700/50 rounded-2xl p-5 hover:border-cyan-500/30 transition-all">
    <div className="flex items-start justify-between mb-3">
      <div className="p-2.5 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-xl">
        <Icon className="w-5 h-5 text-cyan-400" />
      </div>
      {trend && (
        <span className={`text-xs font-medium px-2 py-1 rounded-lg ${trendUp ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
          {trendUp ? '↑' : '↓'} {trend}
        </span>
      )}
    </div>
    <p className="text-2xl font-bold text-white mb-1">{value}</p>
    <p className="text-sm text-slate-400">{label}</p>
    {subtitle && <p className="text-xs text-slate-500 mt-1">{subtitle}</p>}
  </div>
);

const ScoreBadge = ({ score }) => {
  const getColor = (s) => {
    if (s >= 85) return "from-emerald-500 to-green-600";
    if (s >= 70) return "from-cyan-500 to-blue-600";
    if (s >= 55) return "from-amber-500 to-orange-600";
    return "from-slate-500 to-slate-600";
  };
  return (
    <div className={`w-12 h-12 bg-gradient-to-br ${getColor(score)} rounded-xl flex items-center justify-center shadow-lg`}>
      <span className="text-white font-bold">{score}</span>
    </div>
  );
};

const OpportunityRow = ({ opp, onClick, isSelected }) => {
  const stageColors = {
    "RFI": "warning", "Market Research": "purple", "Solicitation": "success",
    "Capture Planning": "info", "Special Notice": "default", "J&A": "default",
  };
  const daysLeft = Math.ceil((new Date(opp.dueDate) - new Date()) / (1000 * 60 * 60 * 24));

  return (
    <div 
      onClick={() => onClick(opp)}
      className={`group flex items-center gap-4 p-4 rounded-xl cursor-pointer transition-all ${
        isSelected ? 'bg-cyan-500/10 border-2 border-cyan-500/50' : 'bg-slate-800/40 hover:bg-slate-700/50 border border-slate-700/50 hover:border-slate-600'
      }`}
    >
      <ScoreBadge score={opp.score} />
      <div className="flex-grow min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="font-semibold text-white truncate text-sm">{opp.title}</h3>
          <Badge variant={stageColors[opp.stage] || "default"} size="xs">{opp.stage}</Badge>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
          <span className="flex items-center gap-1"><Building className="w-3 h-3" /><span className="text-slate-300 font-medium">{opp.acronym}</span></span>
          <span className="flex items-center gap-1"><DollarSign className="w-3 h-3" />{opp.valueDisplay}</span>
          <span className={`flex items-center gap-1 ${daysLeft <= 14 ? 'text-amber-400' : ''}`}>
            <Calendar className="w-3 h-3" />{daysLeft > 0 ? `${daysLeft}d` : 'Past'}
          </span>
          <span className="text-slate-500">{opp.source}</span>
        </div>
      </div>
      <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-cyan-400" />
    </div>
  );
};

const OpportunityDetail = ({ opp, onClose }) => {
  if (!opp) return null;
  const insights = [
    opp.score >= 85 ? "Strong alignment with core capabilities" : "Moderate fit - review requirements",
    opp.acronym === "DHS" ? "Target agency - prioritize relationship building" : `${opp.acronym} is a DHS component agency`,
    opp.stage === "RFI" ? "Early stage - opportunity to shape requirements" : `Current stage: ${opp.stage}`,
    opp.vehicle ? `Contract vehicle: ${opp.vehicle}` : "Vehicle TBD - monitor for updates",
  ];

  return (
    <div className="h-full flex flex-col bg-slate-900 border-l border-slate-700">
      <div className="p-5 border-b border-slate-700">
        <div className="flex items-start justify-between mb-3">
          <ScoreBadge score={opp.score} />
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-lg"><X className="w-5 h-5 text-slate-400" /></button>
        </div>
        <h2 className="text-lg font-bold text-white mb-1">{opp.title}</h2>
        <p className="text-slate-400 text-sm">{opp.agency}</p>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-slate-800/50 rounded-xl p-3 text-center">
            <p className="text-[10px] text-slate-500 uppercase mb-1">Value</p>
            <p className="text-lg font-bold text-white">{opp.valueDisplay}</p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-3 text-center">
            <p className="text-[10px] text-slate-500 uppercase mb-1">Due</p>
            <p className="text-lg font-bold text-white">{opp.dueDate}</p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-3 text-center">
            <p className="text-[10px] text-slate-500 uppercase mb-1">NAICS</p>
            <p className="text-lg font-bold text-white">{opp.naics || "—"}</p>
          </div>
        </div>

        <div>
          <p className="text-xs text-slate-500 mb-1">Solicitation ID</p>
          <p className="text-sm text-white font-mono">{opp.solicitationId}</p>
        </div>

        <div>
          <p className="text-xs text-slate-500 mb-1">Description</p>
          <p className="text-sm text-slate-300">{opp.description}</p>
        </div>

        <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 rounded-xl p-4 border border-cyan-500/20">
          <div className="flex items-center gap-2 mb-3">
            <Zap className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-cyan-400">AI Analysis</h3>
          </div>
          <ul className="space-y-2">
            {insights.map((insight, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-slate-300">
                <CheckCircle className="w-3.5 h-3.5 text-cyan-400 mt-0.5 flex-shrink-0" />
                {insight}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="p-5 border-t border-slate-700 space-y-2">
        <button className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-semibold rounded-xl hover:opacity-90 flex items-center justify-center gap-2">
          <Cloud className="w-4 h-4" /> Push to Salesforce
        </button>
        <button className="w-full py-2.5 bg-slate-800 text-white text-sm rounded-xl hover:bg-slate-700 flex items-center justify-center gap-2">
          <ExternalLink className="w-4 h-4" /> View in G2X
        </button>
      </div>
    </div>
  );
};

const AlertItem = ({ alert }) => {
  const icons = { opportunity: Target, pipeline: Layers, deadline: Clock, competitor: Users };
  const Icon = icons[alert.type] || Bell;
  return (
    <div className={`flex items-start gap-3 p-3 rounded-xl ${alert.priority === 'high' && !alert.read ? 'bg-amber-500/10 border border-amber-500/20' : 'bg-slate-800/40'}`}>
      <div className={`p-2 rounded-lg ${alert.priority === 'high' && !alert.read ? 'bg-amber-500/20' : 'bg-slate-700'}`}>
        <Icon className={`w-4 h-4 ${alert.priority === 'high' && !alert.read ? 'text-amber-400' : 'text-slate-400'}`} />
      </div>
      <div className="flex-grow min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <p className="text-sm font-semibold text-white">{alert.title}</p>
          {!alert.read && <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />}
        </div>
        <p className="text-xs text-slate-400">{alert.message}</p>
        <p className="text-[10px] text-slate-500 mt-1">{alert.time}</p>
      </div>
    </div>
  );
};

const DataSourceCard = ({ source }) => {
  const Icon = source.icon;
  return (
    <div className="flex items-center justify-between p-3 bg-slate-800/40 rounded-xl border border-slate-700/50">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-emerald-500/20">
          <Icon className="w-4 h-4 text-emerald-400" />
        </div>
        <div>
          <p className="text-sm font-medium text-white">{source.name}</p>
          <p className="text-[10px] text-slate-500">{source.records.toLocaleString()} records</p>
        </div>
      </div>
      <div className="text-right">
        <div className="w-2 h-2 rounded-full bg-emerald-400 mb-1 ml-auto" />
        <p className="text-[10px] text-slate-500">{source.lastSync}</p>
      </div>
    </div>
  );
};

const CustomerCard = ({ customer }) => {
  const healthColors = {
    strong: "bg-emerald-500/20 text-emerald-400",
    growing: "bg-cyan-500/20 text-cyan-400",
    new: "bg-purple-500/20 text-purple-400",
  };
  return (
    <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-700/50 hover:border-cyan-500/30 cursor-pointer transition-all">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-xs">{customer.acronym.substring(0, 3)}</span>
          </div>
          <div>
            <h4 className="font-semibold text-white text-sm">{customer.acronym}</h4>
            <p className="text-[10px] text-slate-400 truncate max-w-[120px]">{customer.name}</p>
          </div>
        </div>
        <Badge variant={customer.priority === "Tier 1" ? "info" : "default"} size="xs">{customer.priority}</Badge>
      </div>
      <div className="grid grid-cols-3 gap-2 mb-3 text-center">
        <div><p className="text-lg font-bold text-white">{customer.opportunities}</p><p className="text-[10px] text-slate-500">Opps</p></div>
        <div><p className="text-lg font-bold text-white">{customer.contracts}</p><p className="text-[10px] text-slate-500">Contracts</p></div>
        <div><p className="text-lg font-bold text-white">{customer.relationships}</p><p className="text-[10px] text-slate-500">Contacts</p></div>
      </div>
      <div className="flex items-center justify-between">
        <span className={`text-[10px] px-2 py-1 rounded-full ${healthColors[customer.health]}`}>{customer.health}</span>
        <span className="text-sm font-semibold text-slate-300">{customer.spend}</span>
      </div>
    </div>
  );
};

const PipelineChart = ({ data }) => {
  const maxCount = Math.max(...data.map(d => d.count), 1);
  return (
    <div className="space-y-3">
      {data.map((item, i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="w-28 text-xs text-slate-400 truncate">{item.stage}</div>
          <div className="flex-grow h-7 bg-slate-800 rounded-lg overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg flex items-center justify-end pr-2"
              style={{ width: `${Math.max((item.count / maxCount) * 100, 15)}%` }}
            >
              <span className="text-[10px] text-white font-medium">{item.count}</span>
            </div>
          </div>
          <div className="w-14 text-xs text-slate-300 text-right">{item.value}</div>
        </div>
      ))}
    </div>
  );
};

// Main App
export default function MarketIntelHub() {
  const [activeView, setActiveView] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOpp, setSelectedOpp] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const filteredOpps = OPPORTUNITIES.filter(opp => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return opp.title.toLowerCase().includes(q) || opp.agency.toLowerCase().includes(q) || opp.acronym.toLowerCase().includes(q);
  });

  const navItems = [
    { id: 'dashboard', icon: Home, label: 'Dashboard' },
    { id: 'opportunities', icon: Target, label: 'Opportunities' },
    { id: 'customers', icon: Building, label: 'Customers' },
    { id: 'pipeline', icon: BarChart3, label: 'Pipeline' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="fixed inset-0 bg-gradient-to-br from-cyan-900/10 via-slate-950 to-blue-900/10 pointer-events-none" />
      
      {/* Sidebar */}
      <aside className={`fixed left-0 top-0 bottom-0 w-64 bg-slate-900/90 backdrop-blur-xl border-r border-slate-800 z-40 transform transition-transform lg:translate-x-0 ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="p-5 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-white">Intel Hub</h1>
                <p className="text-[10px] text-slate-400">Alpha Omega Integration</p>
              </div>
            </div>
          </div>
          
          <nav className="flex-1 p-3 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => { setActiveView(item.id); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  activeView === item.id 
                    ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-400 border border-cyan-500/30' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </button>
            ))}
          </nav>
          
          <div className="p-4 border-t border-slate-800">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-slate-400">Data Sources</span>
              <span className="text-emerald-400 font-semibold">4/4 connected</span>
            </div>
            <div className="flex gap-1">
              {DATA_SOURCES.map((s) => (
                <div key={s.id} className="flex-1 h-1.5 rounded-full bg-emerald-500" />
              ))}
            </div>
            <p className="text-[10px] text-slate-500 mt-2">G2X sync: Just now</p>
          </div>
        </div>
      </aside>
      
      {mobileMenuOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setMobileMenuOpen(false)} />}
      
      {/* Main */}
      <main className="lg:ml-64 min-h-screen flex flex-col">
        <header className="sticky top-0 z-20 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
          <div className="flex items-center justify-between px-4 lg:px-6 py-3">
            <div className="flex items-center gap-3 flex-1">
              <button onClick={() => setMobileMenuOpen(true)} className="p-2 hover:bg-slate-800 rounded-xl lg:hidden">
                <Menu className="w-5 h-5 text-slate-400" />
              </button>
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search opportunities..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-800/50 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-400 focus:border-cyan-500 focus:outline-none"
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="relative p-2 hover:bg-slate-800 rounded-xl">
                <Bell className="w-5 h-5 text-slate-400" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-cyan-500 rounded-full" />
              </button>
              <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xs">PC</span>
              </div>
            </div>
          </div>
        </header>
        
        <div className="flex-1 flex">
          <div className={`flex-1 p-4 lg:p-6 overflow-y-auto ${selectedOpp ? 'hidden lg:block lg:w-1/2 xl:w-2/3' : ''}`}>
            
            {activeView === 'dashboard' && (
              <div className="space-y-6">
                <div>
                  <h1 className="text-xl lg:text-2xl font-bold text-white mb-1">DHS Market Intelligence</h1>
                  <p className="text-slate-400 text-sm">Live data from G2Xchange • {OPPORTUNITIES.length} opportunities tracked</p>
                </div>
                
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard icon={Target} label="DHS Opportunities" value={PIPELINE_STATS.activeOpps} trend="2 new" trendUp={true} />
                  <StatCard icon={DollarSign} label="Pipeline Value" value={PIPELINE_STATS.totalValue} subtitle="$62M in Capture" />
                  <StatCard icon={Award} label="Win Rate" value={PIPELINE_STATS.winRate} trend="3%" trendUp={true} />
                  <StatCard icon={Clock} label="Avg Days" value={PIPELINE_STATS.avgDaysToClose} subtitle="To decision" />
                </div>
                
                <div className="grid lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-lg font-semibold text-white">DHS Opportunities</h2>
                      <button onClick={() => setActiveView('opportunities')} className="text-sm text-cyan-400 hover:text-cyan-300 flex items-center gap-1">
                        View all <ArrowUpRight className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="space-y-2">
                      {filteredOpps.slice(0, 5).map((opp) => (
                        <OpportunityRow key={opp.id} opp={opp} onClick={setSelectedOpp} isSelected={selectedOpp?.id === opp.id} />
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-5">
                    <div className="bg-slate-800/30 rounded-2xl border border-slate-700/50 p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold text-white flex items-center gap-2 text-sm">
                          <Bell className="w-4 h-4 text-cyan-400" /> Alerts
                        </h3>
                        <Badge variant="info" size="xs">{ALERTS.filter(a => !a.read).length} new</Badge>
                      </div>
                      <div className="space-y-2">
                        {ALERTS.slice(0, 3).map((alert) => <AlertItem key={alert.id} alert={alert} />)}
                      </div>
                    </div>
                    
                    <div className="bg-slate-800/30 rounded-2xl border border-slate-700/50 p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold text-white flex items-center gap-2 text-sm">
                          <Database className="w-4 h-4 text-cyan-400" /> Sources
                        </h3>
                      </div>
                      <div className="space-y-2">
                        {DATA_SOURCES.map((source) => <DataSourceCard key={source.id} source={source} />)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {activeView === 'opportunities' && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-xl font-bold text-white">DHS Opportunities</h1>
                    <p className="text-slate-400 text-sm">{filteredOpps.length} opportunities from G2Xchange</p>
                  </div>
                  <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-medium rounded-xl">
                    <RefreshCw className="w-4 h-4" /> Sync
                  </button>
                </div>
                <div className="space-y-2">
                  {filteredOpps.map((opp) => <OpportunityRow key={opp.id} opp={opp} onClick={setSelectedOpp} isSelected={selectedOpp?.id === opp.id} />)}
                </div>
              </div>
            )}
            
            {activeView === 'customers' && (
              <div className="space-y-5">
                <div>
                  <h1 className="text-xl font-bold text-white">DHS Component Agencies</h1>
                  <p className="text-slate-400 text-sm">Customer intelligence for Homeland Security portfolio</p>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  {CUSTOMERS.map((customer) => <CustomerCard key={customer.id} customer={customer} />)}
                </div>
              </div>
            )}
            
            {activeView === 'pipeline' && (
              <div className="space-y-5">
                <div>
                  <h1 className="text-xl font-bold text-white">Pipeline Analytics</h1>
                  <p className="text-slate-400 text-sm">DHS opportunities by capture stage</p>
                </div>
                <div className="grid lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 bg-slate-800/30 rounded-2xl border border-slate-700/50 p-5">
                    <h3 className="font-semibold text-white mb-5">Pipeline by Stage</h3>
                    <PipelineChart data={PIPELINE_STATS.byStage} />
                  </div>
                  <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 rounded-2xl border border-cyan-500/20 p-5">
                    <div className="flex items-center gap-2 mb-4">
                      <TrendingUp className="w-5 h-5 text-cyan-400" />
                      <h3 className="font-semibold text-white">Key Opportunity</h3>
                    </div>
                    <p className="text-2xl font-bold text-white mb-1">$62M</p>
                    <p className="text-sm text-slate-400 mb-3">USCIS eAUTO Recompete</p>
                    <p className="text-xs text-slate-300">In Capture Planning stage. Enterprise automation platform for immigration processing.</p>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {selectedOpp && (
            <div className="w-full lg:w-1/2 xl:w-1/3 border-l border-slate-800">
              <OpportunityDetail opp={selectedOpp} onClose={() => setSelectedOpp(null)} />
            </div>
          )}
        </div>
      </main>
      
      <div className="fixed bottom-4 right-4 z-50">
        <div className="flex items-center gap-2 px-3 py-2 bg-slate-800/90 backdrop-blur border border-slate-700 rounded-full text-xs text-slate-400">
          <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
          <span>Live G2X Data</span>
        </div>
      </div>
    </div>
  );
}
