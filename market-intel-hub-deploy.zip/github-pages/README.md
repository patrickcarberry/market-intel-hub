# Market Intelligence Hub

A unified federal business development market intelligence platform. This demo showcases a comprehensive dashboard for aggregating and analyzing federal contracting opportunities from multiple sources.

![Market Intelligence Hub](./preview.png)

## 🚀 Live Demo

**[View Live Demo →](https://alphaomegaintegration.github.io/market-intel-hub)**

## ✨ Features

- **Multi-Source Aggregation** — Unified view of opportunities from SAM.gov, eBuy, GovWin, GovTribe, G2Xchange
- **AI-Powered Scoring** — Intelligent opportunity scoring based on fit, competition, and win probability
- **Customer Intelligence** — Track agency relationships, personnel changes, and procurement patterns
- **Competitive Analysis** — Monitor competitor wins, losses, and market positioning
- **Pipeline Management** — Visual pipeline with stage-by-stage tracking
- **Real-Time Alerts** — Notifications for new opportunities, competitor wins, and market signals
- **Salesforce Integration** — Bidirectional sync with your CRM (in production version)
- **Responsive Design** — Works seamlessly on desktop, tablet, and mobile

## 🛠️ Tech Stack

- **React 18** — UI framework
- **Vite** — Build tool and dev server
- **Tailwind CSS** — Utility-first styling
- **Lucide React** — Icon library
- **GitHub Pages** — Hosting

## 📦 Quick Start

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/alphaomegaintegration/market-intel-hub.git
cd market-intel-hub

# Install dependencies
npm install

# Start development server
npm run dev
```

The app will be available at `http://localhost:3000`

### Build for Production

```bash
npm run build
```

Output will be in the `dist` folder.

## 🚀 Deploy to GitHub Pages

### Option 1: Automated Deployment

```bash
# Build and deploy in one command
npm run deploy
```

This uses the `gh-pages` package to automatically build and push to the `gh-pages` branch.

### Option 2: Manual Deployment

1. **Build the project:**
   ```bash
   npm run build
   ```

2. **Create a new branch for GitHub Pages:**
   ```bash
   git checkout -b gh-pages
   ```

3. **Move build files to root:**
   ```bash
   cp -r dist/* .
   ```

4. **Commit and push:**
   ```bash
   git add .
   git commit -m "Deploy to GitHub Pages"
   git push origin gh-pages
   ```

5. **Enable GitHub Pages:**
   - Go to your repository settings
   - Navigate to Pages
   - Select `gh-pages` branch as source
   - Save

### Option 3: GitHub Actions (Recommended for Teams)

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Build
        run: npm run build
      
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ./dist

  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

## ⚙️ Configuration

### Change Base URL

If deploying to a different repository name, update `vite.config.js`:

```javascript
export default defineConfig({
  base: '/your-repo-name/',
  // ...
})
```

### Customize Branding

Edit the following files:
- `index.html` — Page title, meta tags, favicon
- `src/App.jsx` — Logo, company name, colors

### Add Real API Integrations

The demo uses mock data. To connect to real APIs:

1. Create a backend service (see full project repository)
2. Update API endpoints in `src/api.js`
3. Add environment variables for API keys

## 📁 Project Structure

```
market-intel-hub/
├── public/
│   └── favicon.svg
├── src/
│   ├── App.jsx          # Main application component
│   ├── main.jsx         # Entry point
│   └── index.css        # Global styles + Tailwind
├── index.html           # HTML template
├── package.json         # Dependencies and scripts
├── vite.config.js       # Vite configuration
├── tailwind.config.js   # Tailwind configuration
└── README.md            # This file
```

## 🎨 Customization

### Color Scheme

The app uses a dark theme with cyan/blue accents. Modify `tailwind.config.js` to change:

```javascript
theme: {
  extend: {
    colors: {
      // Add custom colors
      brand: {
        50: '#f0fdfa',
        // ...
        900: '#134e4a',
      }
    }
  }
}
```

### Adding New Data Sources

1. Add source to `MOCK_DATA_SOURCES` array in `App.jsx`
2. Create corresponding API integration in backend
3. Update the data aggregation logic

## 🔒 Security Notes

- This demo does **not** store or transmit any real credentials
- API keys should be stored in environment variables, never in code
- Production deployment should use HTTPS and proper authentication

## 📄 License

Proprietary — Alpha Omega Integration

For licensing inquiries: bd@alphaomegaintegration.com

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📞 Support

- **Documentation:** [docs.alphaomegaintegration.com](https://docs.alphaomegaintegration.com)
- **Email:** support@alphaomegaintegration.com
- **Issues:** [GitHub Issues](https://github.com/alphaomegaintegration/market-intel-hub/issues)

---

Built with ❤️ by [Alpha Omega Integration](https://alphaomegaintegration.com)
